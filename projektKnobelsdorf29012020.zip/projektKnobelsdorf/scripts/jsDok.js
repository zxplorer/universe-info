{ "use strict";

allUserInput = document.getElementsByTagName("input");
var textAreaInput=document.getElementById("NachrichtGast");
var coll = document.getElementsByClassName("collapsible");
var i;
var fenstersize= window.matchMedia("(max-width:768px)");
for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() { // "col" sind alle "collapsible"'s
    this.classList.toggle("active");            // this statt e vom (e) Parameter
    this.classList.add("gelesen");             //  Element "ein/ausklappen" + Klasse
    var content = this.nextElementSibling;    //   der Textinhalt in "content" 
    var fotoArt= this.previousElementSibling;//    das umschließende "figure"
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
    
    var mainDiv = document.getElementById("main");
    content.style.size = "80%";    


    if (mainDiv.style.gridTemplateColumns==="1fr") {
      if (!fenstersize.matches){
      mainDiv.style.gridTemplateColumns = "1fr 1fr"; }
      else mainDiv.style.gridTemplateColumns = "1fr";

    } else {
      mainDiv.style.gridTemplateColumns = "1fr";
      this.scrollIntoView(false);
    }
    if (fotoArt.lastElementChild) {fotoArt.lastElementChild.classList.toggle("bildVergroessern");}
  });
}

let submit = document.querySelector("[type=submit]");
let form = document.querySelector("form");
	
submit.addEventListener("click",
	function(e){
    checkUserInput();
		e.preventDefault();},
		false);
	
	let checkUserInput = () =>{
    let userName = allUserInput.namedItem('VorNachname').value;
    let userBday = document.getElementById("geburtstag").value;
    let userThema = document.getElementById("themen").value;
    let userVerbesserung =document.getElementById("verbesserungen").value;
    let userNachricht = document.getElementById("NachrichtGast").value;
        if (userName.length == 0 || userBday.length == 0)
        {
          makeElement("Wenn Sie an der Umfrage teilnehmen möchten füllen Sie bitte mindestens Ihren Namen und Ihr Geburtsdatum aus. Vielen Dank :)");
        }
        else 
        {
          makeElement("Vielen Dank für Ihre Eingaben."); 
          console.log("Ihr eingegebener Name: " + userName + ". Ihr Geburtsdatum: " 
          + userBday + ". Ihre Meinung zu den Themen: " + userThema + ". Als Verbesserung schlagen Sie vor: "
          + userVerbesserung + ". Ihre zusätzliche Nachricht: " + userNachricht);
        }
	}
	

	let makeElement = (nachricht) => {
        if (form.hasChildNodes())
        {
        form.removeChild(form.lastChild)
        }
		    let p = document.createElement("p");
		    let message = document.createTextNode(nachricht);
		    p.appendChild(message);
        form.appendChild(p);
	}	

  /*
  Schlusskommentar: Ich verwende manchmal "var" statt "let" weil ich will, dass die Variablen 
  von überall sichtbar sind.
  Die Ausgabe der form-Eingaben hatte ich zuerst auch ins HTML Dokument für den User sichtbar gemacht, aber 
  eine kurze (Miss-)Erfolgsmeldung fand ich dann doch schöner. 
  */
}
