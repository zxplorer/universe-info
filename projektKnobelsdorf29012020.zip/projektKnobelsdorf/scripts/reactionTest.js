{
    "use strict";

var clickedTime; var createdTime; var reactionTime; 

function makeBox() {
    var time=Math.random();
    time=time*3000;
  
  setTimeout(function() {     
    var top= Math.random();
      top= top*60;
    var left= Math.random();
      left= left*50; 
      
    document.getElementById("reaktionsBox").style.top = top + "%";
    document.getElementById("reaktionsBox").style.left = left + "%"; 
    document.getElementById("reaktionsBox").style.display="block";    
    createdTime=Date.now();   
  }, time); 

}

  document.getElementById("reaktionsBox").onclick=function() {

  clickedTime=Date.now();
  if( reactionTime == null){
    oldReactTime =0;
  }
  else{
  var oldReactTime= reactionTime;
  }
  reactionTime=(clickedTime-createdTime)/1000;
  var section= document.getElementsByTagName("section");

  if(oldReactTime>reactionTime && oldReactTime!=0){
  document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
  section[0].innerHTML= "Sie haben sich verbessert! Weiter so :)";
  section[0].style.color="green";
 }
  else if (oldReactTime==0){
    document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
    section[0].innerHTML= "";
  }
  else {
    document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
    section[0].innerHTML= "Sie haben sich verschlechtert :( Weiterüben! ";
    section[0].style.color="darkred"
  }
  this.style.display="none";  
  makeBox();
   
}

//die gleiche funktion für touchscreen 
document.getElementById("reaktionsBox").ontouchstart=function() {
  clickedTime=Date.now();
  if( reactionTime == null){
    oldReactTime =0;
  }
  else{
  var oldReactTime= reactionTime;
  }
  reactionTime=(clickedTime-createdTime)/1000;
  var section= document.getElementsByTagName("section");

  if(oldReactTime>reactionTime && oldReactTime!=0){
  document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
  section[0].innerHTML= "Sie haben sich verbessert! Weiter so :)";
  section[0].style.color="green";
 }
  else if (oldReactTime==0){
    //document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
    section[0].innerHTML= "";
  }
  else {
    document.getElementById("printReactionTime").innerHTML="Ihre Reaktionszeit beträgt: " + reactionTime + " Sekunden.";
    section[0].innerHTML= "Sie haben sich verschlechtert :( Weiterüben! ";
    section[0].style.color="darkred"
  }
  this.style.display="none";  
  makeBox();
}
}